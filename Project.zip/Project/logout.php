<?php 
	session_start();

	echo "<script> alert('apakah anda yakin akan keluar ?')</script>";
	unset($_SESSION['username']);
	session_destroy();
	header('location:login.php');
 ?>