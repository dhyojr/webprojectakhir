<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<title>login</title>
</head>
<body background="images/record.jpg">
	<div class="container">
	
	</div>
	<div class='container' style="width: 20%;background-color:black" >
		<br>
	    <form action="" method="post" enctype="multipart/from-data">
	    	<img src="images/logo.jpg" width="240" height="220">
			<div class='form-group'>
				<center><h4><font color="white">Silahkan Login</h4></center>
				<font color="white" size="4"></label>
				<input type="text" name="username" class='form-control' placeholder="username">
		 	</div>
		  	<div class='form-group'>
				<font color="white" size="4"></label>
				<input type="password" name="password" class='form-control' placeholder="password">
				<center><h6><font color="white">Belum punya akun? click Daftar</h6></center>
		 	</div>
		  	<button  type ="submit" class="btn btn-primary" name="login">Login </button>
		  	<a href="form_simpan_login.php" class="btn btn-primary">Daftar</a>
			<br>
			<font color="black">a</font>
	  	</form>
	</div>

<?php  
	if(isset($_POST['login'])){
	include ('koneksi.php');
	session_start();
		$username = $_POST['username'];
		$password = $_POST['password'];

		$query = mysqli_query($conn," SELECT*FROM user WHERE username = '$username' and password= '$password' ");
		$hasil = mysqli_fetch_assoc($query);

		if ($hasil !=NULL) {
			$hak_akses = $hasil['hak_akses'];
			if ($hak_akses == 'admin') {
				$_SESSION['username']	= $username;
				header('location:halamanadmin.php');
			}
			elseif ($hak_akses == 'user') {
				$_SESSION['username']	= $username;
				header('location:index.html');
			}
		}else{
			header('location:login.php');
		}
	}
?>
</body>
</html>