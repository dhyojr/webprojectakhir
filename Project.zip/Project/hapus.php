<?php 
include 'koneksi.php';
$id = $_GET['id'];
$delete=  "DELETE FROM toko where id ='$id'";
$delete_query = mysqli_query($conn,$delete);
 
header("location:halamanadmin.php");
?>