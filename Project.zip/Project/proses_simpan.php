<?php
require_once "koneksi.php";
$nama = $_POST['nama'];
$alamat = $_POST['alamat'];
$nohp = $_POST['nohp'];
$tanggalpinjam = $_POST['tanggalpinjam'];
$tanggalkembali = $_POST['tanggalkembali'];
$harga = $_POST['harga'];
$barang = $_POST['barang'];
$Foto = $_FILES['foto']['name'];
$tmp = $_FILES['foto']['tmp_name'];
$Fotobaru = date('dmYHis').$Foto;
$path = "images/".$Fotobaru;

if(move_uploaded_file($tmp, $path)){ 
  $query = "INSERT INTO toko (nama,alamat,nohp,tanggalpinjam,tanggalkembali,barang,foto) VALUES
  ('".$nama."', '".$alamat."', '".$nohp."', '".$tanggalpinjam."', '".$tanggalkembali."',
  '".$barang."', '".$Fotobaru."')";
  $sql = mysqli_query($conn, $query);
  if($sql){ 
    header("location: index.html"); 
  }else{
    echo "Maaf, Terjadi kesalahan saat mencoba untuk menyimpan data ke database.";
    echo "<br><a href='index.html'>Kembali Ke Form</a>";
  }
}else{
  echo "Maaf, Gambar gagal untuk diupload.";
  echo "<br><a href='index.html'>Kembali Ke Form</a>";
}
?>