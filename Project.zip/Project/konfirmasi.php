<?php
include ("koneksi.php");
?>
<!DOCTYPE HTML>
<html>
  <head>
    <title>Ryuu Sewa Alat Musik</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" href="assets/css/main.css" />
  </head>
  <body>
    <div class="page-wrap">
        <section id="main">
            <section id="banner">
              <div class="inner">
                <h1>Welcome</h1>
                <p>Hardwork Broooo</a></p>
                <ul class="actions">
                  <li>
                    <a href="logout.php" class="button alt scrolly big">Logout</a>
                  </li>

                </ul>
              </div>
            </section>
  <?php 
    require_once "koneksi.php";
    $query = mysqli_query($conn, "SELECT * FROM toko where id='".$_GET['id']."'");
    $hasil = mysqli_fetch_assoc($query);
 ?>
 <p>
 <div class="container">
  <center><h1>Edit Data Toko</h1></center>
  <hr>
  <br>
  <form action="edit.php?id=<?php echo $hasil ['id']?> " method="post" enctype="multipart/form-data">
  <table cellpadding="8">
    <input type="hidden" name="id" value="<?php echo $hasil['id'];?>">
  <div class="form-group">
    <input type="number" name="id" id="" class="form-control" placeholder="Masukkan ID" value="<?php echo $hasil['id'];?>">
   </div>
  <div class="form-group">
      <input type="text" name="nama" id="" class="form-control" placeholder="Masukkan Nama" value="<?php echo $hasil['nama'];?>">
    </div>
    <div class="form-group">
      <input type="text" name="alamat" id="" class="form-control" placeholder="Masukkan alamat" value="<?php echo $hasil['alamat'];?>">
    </div>
  <fieldset class="form-group" name="jenis_obat">
      <div class="row">
         <legend class="col-form-label col-sm-2 pt-0">Jenis Obat</legend>
          <div class="col-sm-10">
            <div class="form-check">
              <input class="form-check-input" type="radio" name="jenis_obat" id="" value="tablet" <?php 
              echo ($hasil['jenis_obat']=='tablet')?'checked':'' ?>>
              <label class="form-check-label">
               tablet
              </label>
            </div>
            <div class="form-check">
              <input class="form-check-input" type="radio" name="jenis_obat" id="" value="pil" <?php 
              echo ($hasil['jenis_obat']=='pil')?'checked':'' ?>>
              <label class="form-check-label">
               pil
            </div>
            <div class="form-check">
             <input class="form-check-input" type="radio" name="jenis_obat" id="" value="kapsul" <?php 
              echo ($hasil['jenis_obat']=='kapsul')?'checked':'' ?>>
              <label class="form-check-label">
               kapsul
            </div>
            <div class="form-check">
              <input class="form-check-input" type="radio" name="jenis_obat" id="" value="kaplet" <?php 
              echo ($hasil['jenis_obat']=='kaplet')?'checked':'' ?>>
              <label class="form-check-label">
              kaplet
            </div>
            <div class="form-check">
           <input class="form-check-input" type="radio" name="jenis_obat" id="" value="sirup" <?php 
               echo ($hasil['jenis_obat']=='sirup')?'checked':'' ?>>
            <label class="form-check-label">
            sirup
        </div>
      </div>
    </div>
  </fieldset>
  <div class="form-group">
      <input type="date" name="tanggalmasuk" id="" class="form-control"  value="<?php echo $hasil['tanggalmasuk'];?>">
    </div>
  <div class="custom-file">
    <input type="file" class="custom-file-input" id="customFile" name="foto">
  <label class="custom-file-label">Pilih Gambar</label>
</div>
<br>
<br>
  </table>
  <input type="submit" value="Simpan">
  <a href="index.php"><input type="button" value="Batal"></a>
  </form>
</div>
 </p>
  </body>
</html>