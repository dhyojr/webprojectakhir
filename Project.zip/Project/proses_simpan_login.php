<?php
require_once "koneksi.php";
$username = $_POST['username'];
$password = $_POST['password'];
$hak_akses = $_POST['hak_akses'];

$query = "INSERT INTO user (username,password,hak_akses) VALUES ('".$username."', '".$password."', '".$hak_akses."')";
 $sql = mysqli_query($conn, $query);
  if($sql){ 
    header("location: login.php"); 
  }else{
    echo "Maaf, Terjadi kesalahan saat mencoba untuk menyimpan data ke database.";
    echo "<br><a href='form_simpan_login.php'>Kembali Ke Form</a>";
  }
?>