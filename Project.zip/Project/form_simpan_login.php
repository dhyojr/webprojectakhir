<?php
include ("koneksi.php");
?>
<html>
<head>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <title>login</title>
</head>
<body background="images/record.jpg">
  <div class="container">
  
  </div>
  <div class='container' style="width: 20%;background-color:black" >
    <br>
      <form action="proses_simpan_login.php" method="post" enctype="multipart/from-data">
        <img src="images/logo.jpg" width="240" height="220">
      <div class='form-group'>
        <center><h5><font color="white">Welcome to Ryuu studio</h5></center>
        <font color="white" size="4">username</label>
        <input type="text" name="username" class='form-control' placeholder="username">
      </div>
        <div class='form-group'>
        <font color="white" size="4">password</label>
        <input type="password" name="password" class='form-control' placeholder="password">
      </div>
      <div class='form-group'>
        <font color="white" size="4">hak_akses</label>
        <input type="text" name="hak_akses" class='form-control' placeholder="hak akses">
      </div>
        <input type="submit" class="btn btn-primary" value="Simpan">
        <a href="login.php" class="btn btn-primary">Batal</a>
      <br>
      <font color="black">a</font>
      </form>
  </div>

</html>