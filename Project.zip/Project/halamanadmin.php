<?php
include ("koneksi.php");
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>Ryuu Sewa Alat Musik</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="assets/css/main.css" />
	</head>
	<body>
		<div class="page-wrap">
				<section id="main">
						<section id="banner">
							<div class="inner">
								<h1>Welcome</h1>
								<p>Hardwork Broooo</a></p>
								<ul class="actions">
									<li>
										<a href="logout.php" class="button alt scrolly big">Logout</a>
									</li>

								</ul>
							</div>
						</section>
	<?php
		$query		= mysqli_query($conn,"SELECT * FROM toko");
	?>	
	<table border="1" align="center" cellpadding="5" cellspacing="2">
		<thead>
			<tr>
				<th>ID</th>
				<th>Nama User</th>
				<th>Alamat </th>
				<th>no hp</th>
				<th>Tanggal Pinjam</th>
				<th>Tanggal Kembali</th>
				<th>Harga</th>
				<th>Barang</th>
				<th>Foto</th>
				<th>fungsi</th>
			</tr>
		</thead>
		<tbody>
			<?php
				while($hasil	= mysqli_fetch_assoc($query)) {
			?>
			<tr>
				<td><?php echo $hasil['id']?></td>
				<td><?php echo $hasil['nama']?></td>
				<td><?php echo $hasil['alamat']?></td>
				<td><?php echo $hasil['nohp']?></td>
				<td><?php echo $hasil['tanggalpinjam']?></td>
				<td><?php echo $hasil['tanggalkembali']?></td>
				<td><?php echo $hasil['harga']?></td>
				<td><?php echo $hasil['barang']?></td>
				<td><center><img src="images/<?php echo $hasil['foto']?>" height="100px"></center></td>
				<td><center><a href="konfirmasi.php?id=<?php echo $hasil['id'];?>">Konfirmasi</a> &nbsp
				<a href="hapus.php?id=<?php echo $hasil['id'];?>">hapus</a>
			</center>
		</td>

			</tr>
			<?php }?>
		</tbody>
	</table>
	</body>
</html>